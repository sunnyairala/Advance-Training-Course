import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { medicines } from 'src/app/models/medicines.model';
import { CartService } from 'src/app/services/cart.service';
import { MedicineService } from 'src/app/services/medicines.service';



@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
    styleUrls: ['./search.component.css']
    
})
export class SearchComponent implements OnInit {

  @Output() searchText = new EventEmitter();
  searchString: string = '';
  medicines!: medicines[];

  constructor(private medicineService:MedicineService,private router: Router,
    private route: ActivatedRoute, private cartService : CartService) { }

  ngOnInit(): void {
    
    this.medicineService.getMedicines().subscribe((med)=>{
      this.medicines = med;      
    })
  }
  passSearchText(): void {
    this.searchText.emit(this.searchString);
  }
}
